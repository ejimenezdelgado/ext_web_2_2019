var animales = ["perro", "gato", "pez"];

var totalAnimales = animales.length;

for (var i = 0; i < totalAnimales; i++) {
	console.log(animales[i]);
};
