var mensaje = "¡Hola Mundo!";
estado = "activo";
resultado = 45;

console.log(mensaje);
console.log(estado);
console.log(resultado);